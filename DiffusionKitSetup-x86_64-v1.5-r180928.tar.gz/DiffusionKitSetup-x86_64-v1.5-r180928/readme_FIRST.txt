Basically, the package can be extracted and used directly.
If you encounter errors like following:
libstdc++.so.6: version `CXXABI_1.3.8' not found
please enter the subfolder DiffusionKitSetup-x86_64-v1.5-r180928/bin
and execute the following command:
source setpath.rc
